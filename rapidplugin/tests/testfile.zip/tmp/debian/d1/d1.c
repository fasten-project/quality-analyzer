class c
{
    int d(){}
}